# 1806133805 - Muhammad Aulia Akbar

## Quickstart

1. build `docker-compose build`

2. run `docker-compose up` (jalankan tanpa -d agar dapat melihat log)

## URL

1. web `localhost:8000` atau `10.5.0.5`
2. rest `10.5.0.6`

## Gambar

1. browser  
![browser](browser.png)
2. serverlog  
![serverlog](serverlog.png)
